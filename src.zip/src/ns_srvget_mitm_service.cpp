/*
 * Copyright (c) 2018 p-sam, 2026 MasaGratoR
 * Adapted for sys-icon
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 */

#include <switch.h>
#include "ns_srvget_mitm_service.hpp"
#include "file_utils.hpp"

// ─── ini parsing ─────────────────────────────────────────────────────────────
// Reads sdmc:/atmosphere/contents/<tid>/config.ini and applies name/author/
// display_version overrides into the Nacp buffer.

static void ini_parse(const char* path, void* buffer, u64 tid) {
	Nacp* nacp = (Nacp*)buffer;

	FILE* f = fopen(path, "r");
	if (f == NULL) return;
	char ini[1024];
	size_t size = fread(ini, 1, sizeof(ini)-1, f);
	fclose(f);
	ini[size] = 0;

	if (memcmp(ini, "[override_nacp]", 15)) {
		FileUtils::LogLine("ini_parse(%016lx) // [override_nacp] not found", tid);
		return;
	}

	const char* name   = strstr(ini, "name=");
	const char* author = strstr(ini, "author=");

	if (name && author) {
		const char* m_name   = &name[5];
		const char* m_author = &author[7];
		size_t m_name_len   = strcspn(m_name, "\r\n");
		size_t m_author_len = strcspn(m_author, "\r\n");
		if (m_name_len <= 0x200 && m_author_len <= 0x100) {
			memset((void*)&nacp->lang_data, 0, sizeof(nacp->lang_data));
			for (unsigned int i = 0; i < 16; i++) {
				memcpy(nacp->lang_data.lang[i].name,   m_name,   m_name_len);
				memcpy(nacp->lang_data.lang[i].author, m_author, m_author_len);
			}
			nacp->titles_data_format = 0;
			FileUtils::LogLine("ini_parse(%016lx) // name+author ok", tid);
		} else {
			FileUtils::LogLine("ini_parse(%016lx) // size check failed: name=%d author=%d", tid, (int)m_name_len, (int)m_author_len);
		}
	} else {
		FileUtils::LogLine("ini_parse(%016lx) // name=%d author=%d not found", tid, name!=nullptr, author!=nullptr);
	}

	const char* display_version = strstr(ini, "display_version=");
	if (display_version) {
		const char* m_ver = &display_version[16];
		size_t m_ver_len  = strcspn(m_ver, "\r\n");
		if (m_ver_len <= 0x10) {
			memset(nacp->display_version, 0, sizeof(nacp->display_version));
			memcpy(nacp->display_version, m_ver, m_ver_len);
			FileUtils::LogLine("ini_parse(%016lx) // display_version ok", tid);
		}
	}
}

// ─── Icon / NACP patching ────────────────────────────────────────────────────
// flag==0 → icon.jpg   (standard 256x256)
// flag==1 → icon174.jpg (174x174 used by some cmds on FW20+)
// out_size is u32* for cmd 0, and points inside a {u32 unk, u32 size} struct
// for cmds 5 and 19.

[[maybe_unused]] static void _ProcessControlData(u64 tid, u8* buf, size_t buf_size, u32* out_size, u8 flag) {
	if (buf_size < sizeof(Nacp)) return;

	char path[0x80] = "";

	// config.ini overrides
	snprintf(path, sizeof(path)-1, "sdmc:/atmosphere/contents/%016lx/config.ini", tid);
	FILE* cfg = fopen(path, "r");
	if (cfg != NULL) {
		fclose(cfg);
		ini_parse(path, buf, tid);
	} else {
		FileUtils::LogLine("_ProcessControlData(%016lx) // no config.ini", tid);
	}

	// icon.jpg or icon174.jpg — with automatic fallback.
	// If flag!=0 (174x174 requested) and icon174.jpg doesn't exist,
	// fall back to icon.jpg so you only ever need one file.
	void* icon = &buf[sizeof(Nacp)];
	snprintf(path, sizeof(path)-1, "sdmc:/atmosphere/contents/%016lx/icon%s.jpg", tid, flag ? "174" : "");

	FILE* f = fopen(path, "rb");
	if (f == NULL && flag) {
		// icon174.jpg not found — fall back to icon.jpg
		FileUtils::LogLine("_ProcessControlData(%016lx) // icon174.jpg not found, falling back to icon.jpg", tid);
		snprintf(path, sizeof(path)-1, "sdmc:/atmosphere/contents/%016lx/icon.jpg", tid);
		f = fopen(path, "rb");
	}
	if (f == NULL) {
		FileUtils::LogLine("_ProcessControlData(%016lx) // no icon found, skipping", tid);
		return;
	}

	fseek(f, 0, SEEK_END);
	long icon_size = ftell(f);
	fseek(f, 0, SEEK_SET);

	long max_icon_size = (long)(buf_size - sizeof(Nacp));
	bool loaded = false;
	if (icon_size <= max_icon_size) {
		size_t bytes_read = fread(icon, 1, icon_size, f);
		if (bytes_read > 0) {
			*out_size = sizeof(Nacp) + bytes_read;
			loaded = true;
		}
	} else {
		FileUtils::LogLine("_ProcessControlData(%016lx) // icon too big! size=%ld max=%ld", tid, icon_size, max_icon_size);
	}
	fclose(f);

	FileUtils::LogLine("_ProcessControlData(%016lx) flag=%u out_size=%u %s",
	                   tid, flag, *out_size, loaded ? "OK" : "FAILED");
}

// ─── ShouldMitm ──────────────────────────────────────────────────────────────
// ns:am2 → only intercept qlaunch (and ulaunch, which runs AS qlaunch)
// ns:ro  → only intercept ppc (background NS worker)

bool NsAm2MitmService::ShouldMitm(const ams::sm::MitmProcessInfo& client_info) {
	bool should_mitm = (client_info.program_id == ams::ncm::SystemAppletId::Qlaunch);
	FILE_LOG_IPC(NSAM2_MITM_SERVICE_NAME, client_info, "() // %s", should_mitm ? "true" : "false");
	return should_mitm;
}

bool NsRoMitmService::ShouldMitm(const ams::sm::MitmProcessInfo& client_info) {
	bool should_mitm = (client_info.program_id == ams::ncm::SystemProgramId::Ppc);
	FILE_LOG_IPC(NSRO_MITM_SERVICE_NAME, client_info, "() // %s", should_mitm ? "true" : "false");
	return should_mitm;
}

// ─── GetROAppControlDataInterface ────────────────────────────────────────────
// Forwards cmd 7989 to the real service, wraps the returned sub-session.
// CRITICAL: must pass target_object_id for domain sessions (qlaunch uses domains).

ams::Result NsServiceGetterMitmService::GetROAppControlDataInterface(ams::sf::Out<ams::sf::SharedPointer<NsROAppControlDataInterface>> out) {
	Service s;
	Result rc = serviceDispatch(this->m_forward_service.get(), (u32)NsSrvGetterCmdId::GetROAppControlDataInterface,
		.out_num_objects = 1,
		.out_objects = &s,
	);

	if (R_SUCCEEDED(rc)) {
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&s)};
		out.SetValue(ams::sf::CreateSharedObjectEmplaced<NsROAppControlDataInterface, NsROAppControlDataService>(this->m_client_info, std::make_unique<Service>(s)), target_object_id);
	}

	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// ─── Sub-session command implementations ─────────────────────────────────────

// cmd 0: GetAppControlData — the main icon/NACP fetch (flag=0 → icon.jpg)
ams::Result NsROAppControlDataService::GetAppControlData(u8 flag, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<u32> out_size) {
	const struct { u8 flag; u64 tid; } in = {flag, tid};

	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);

	FILE_LOG_IPC_CLASS("(%u, 0x%016lx, buf[0x%lx]) // %x[0x%x]", flag, tid, buffer.GetSize(), rc, out_size.GetValue());

	if (R_SUCCEEDED(rc) && FileUtils::WaitInitialized()) {
		_ProcessControlData(tid, buffer.GetPointer(), buffer.GetSize(), out_size.GetPointer(), 0);
	}
	return rc;
}

// cmd 1: pure forward
ams::Result NsROAppControlDataService::GetAppDesiredLanguage(u32 bitmask, ams::sf::Out<u8> out_langentry) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppDesiredLanguage, bitmask, *out_langentry.GetPointer());
	FILE_LOG_IPC_CLASS("(0x%08x) // %x[%u]", bitmask, rc, out_langentry.GetValue());
	return rc;
}

// cmd 2: pure forward
ams::Result NsROAppControlDataService::ConvertAppLanguageToLanguageCode(u8 langentry, ams::sf::Out<u64> out_langcode) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::ConvertAppLanguageToLanguageCode, langentry, *out_langcode.GetPointer());
	FILE_LOG_IPC_CLASS("(0x%02x) // %x", langentry, rc);
	return rc;
}

// cmd 3: pure forward
ams::Result NsROAppControlDataService::ConvertLanguageCodeToAppLanguage(u64 langcode, ams::sf::Out<u8> out_langentry) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::ConvertLanguageCodeToAppLanguage, langcode, *out_langentry.GetPointer());
	FILE_LOG_IPC_CLASS("(0x%016lx) // %x", langcode, rc);
	return rc;
}

// cmd 4: pure forward (different signature from old code — has in+out buffers)
ams::Result NsROAppControlDataService::SelectApplicationDesiredLanguage(ams::sf::Out<u64> out_bytes, const ams::sf::InMapAliasBuffer &in_buffer) {
	Result rc = serviceDispatchOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::SelectApplicationDesiredLanguage, *out_bytes.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_buffer.GetPointer(), in_buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 5: GetAppControlData5 — extra source+flag params, patches icon (flag → icon174.jpg if flag!=0)
ams::Result NsROAppControlDataService::GetAppControlData5(u8 source, u8 flag, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<u64> out_size) {
	const struct { u8 source; u8 flag; u64 tid; } in = {source, flag, tid};

	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData5, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);

	// out_size is actually {u32 unk, u32 size} packed into a u64
	struct out_data { u32 unk; u32 size; };
	out_data* data = (out_data*)out_size.GetPointer();

	FILE_LOG_IPC_CLASS("(%u, %u, 0x%016lx, buf[0x%lx]) // %x[0x%x]", source, flag, tid, buffer.GetSize(), rc, data->size);

	if (R_SUCCEEDED(rc) && FileUtils::WaitInitialized()) {
		_ProcessControlData(tid, buffer.GetPointer(), buffer.GetSize(), &data->size, flag);
	}
	return rc;
}

// cmd 6: GetAppControlData6 — extra flags, NOT patching (commented out in sys-ticon, keep same)
ams::Result NsROAppControlDataService::GetAppControlData6(u8 source, u8 flag1, u8 flag2, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<u64> out_size) {
	const struct { u8 source; u8 flag1; u8 flag2; u64 tid; } in = {source, flag1, flag2, tid};

	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData6, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);

	FILE_LOG_IPC_CLASS("(%u, %u, %u, 0x%016lx, buf[0x%lx]) // %x", source, flag1, flag2, tid, buffer.GetSize(), rc);
	return rc;
}

// cmd 7: pure forward
ams::Result NsROAppControlDataService::Unk7(u64 tid, ams::sf::Out<Struct0x80> out_bytes) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk7, tid, *out_bytes.GetPointer());
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 8: pure forward
ams::Result NsROAppControlDataService::Unk8(Struct0x88 in_bytes, ams::sf::Out<u32> out_bytes, const ams::sf::OutMapAliasBuffer &out_buffer) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk8, in_bytes, *out_bytes.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{out_buffer.GetPointer(), out_buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 9: pure forward
ams::Result NsROAppControlDataService::Unk9(u64 tid, const ams::sf::InMapAliasBuffer &in_buffer) {
	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk9, tid,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_buffer.GetPointer(), in_buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 10: GetAppTitleAsync — returns IAsyncValue sub-object
ams::Result NsROAppControlDataService::GetAppTitleAsync(Struct0x10 in_bytes, const ams::sf::InMapAliasArray<u64> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppTitleAsync, in_bytes,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::GetAppTitleAsync), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 11: Unk11 — returns IAsyncValue
ams::Result NsROAppControlDataService::Unk11(size_t tmem_size, const ams::sf::InMapAliasArray<Struct0x10> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk11, tmem_size,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::Unk11), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 12: Unk12 — returns IAsyncValue
ams::Result NsROAppControlDataService::Unk12(Struct0x10 in_bytes, const ams::sf::InMapAliasArray<Struct0x10> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk12, in_bytes,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::Unk12), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 13: GetAppTitle2Async — returns IAsyncValue
ams::Result NsROAppControlDataService::GetAppTitle2Async(size_t tmem_size, const ams::sf::InMapAliasArray<u64> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppTitle2Async, tmem_size,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::GetAppTitle2Async), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 14: Unk14 — returns IAsyncValue
ams::Result NsROAppControlDataService::Unk14(Struct0x10 in_bytes, const ams::sf::InMapAliasArray<u64> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk14, in_bytes,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::Unk14), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 15: Unk15 — returns IAsyncValue
ams::Result NsROAppControlDataService::Unk15(Struct0x10 in_bytes, const ams::sf::InMapAliasArray<u64> &in_array, ams::sf::CopyHandle &&in_handle, ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncValueInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatchIn(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk15, in_bytes,
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_In},
		.buffers = {{in_array.GetPointer(), in_array.GetSize() * sizeof(in_array.GetPointer()[0])}},
		.in_num_handles = 1,
		.in_handles = {in_handle.GetOsHandle()},
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncValueInterface, AsyncValueService>(this->m_client_info, std::make_unique<Service>(temp_out_interface), NsROAppControlDataInterfaceCmdId::Unk15), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 16: Unk16 — returns IAsyncResult
ams::Result NsROAppControlDataService::Unk16(ams::sf::OutCopyHandle out_handle, ams::sf::Out<ams::sf::SharedPointer<AsyncResultInterface>> out_interface) {
	Handle temp_out_handle = INVALID_HANDLE;
	Service temp_out_interface;

	Result rc = serviceDispatch(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk16,
		.out_num_objects = 1,
		.out_objects = &temp_out_interface,
		.out_handle_attrs = {SfOutHandleAttr_HipcCopy},
		.out_handles = {&temp_out_handle},
	);

	if (R_SUCCEEDED(rc)) {
		out_handle.SetValue(temp_out_handle, true);
		const ams::sf::cmif::DomainObjectId target_object_id{serviceGetObjectId(&temp_out_interface)};
		out_interface.SetValue(ams::sf::CreateSharedObjectEmplaced<AsyncResultInterface, AsyncResultService>(this->m_client_info, std::make_unique<Service>(temp_out_interface)), target_object_id);
	}
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 17: pure forward with out buffer
ams::Result NsROAppControlDataService::Unk17(Struct0x90 in_bytes, ams::sf::Out<u32> out_bytes, const ams::sf::OutMapAliasBuffer &out_buffer) {
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::Unk17, in_bytes, *out_bytes.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{out_buffer.GetPointer(), out_buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("() // %x", rc);
	return rc;
}

// cmd 18: pure forward (not patching — same as sys-ticon)
ams::Result NsROAppControlDataService::GetAppControlData18(u8 source, u8 flag1, u8 flag2, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<u64> out_size) {
	const struct { u8 source; u8 flag1; u8 flag2; u64 tid; } in = {source, flag1, flag2, tid};

	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData18, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("(%u, 0x%016lx, buf[0x%lx]) // %x", source, tid, buffer.GetSize(), rc);
	return rc;
}

// cmd 19: GetAppControlData19 — patches icon (flag → icon174.jpg if flag!=0)
ams::Result NsROAppControlDataService::GetAppControlData19(u8 source, u8 flag, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<Struct0xC> out_size) {
	const struct { u8 source; u8 flag; u64 tid; } in = {source, flag, tid};

	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData19, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);

	// out_size is Struct0xC = {u32 unk1, u32 unk2, u32 size}
	struct out_data { u32 unk1; u32 unk2; u32 size; };
	out_data* data = (out_data*)out_size.GetPointer();

	FILE_LOG_IPC_CLASS("(%u, %u, 0x%016lx, buf[0x%lx]) out[0x%x] // %x", source, flag, tid, buffer.GetSize(), data->size, rc);

	if (R_SUCCEEDED(rc) && FileUtils::WaitInitialized()) {
		_ProcessControlData(tid, buffer.GetPointer(), buffer.GetSize(), &data->size, flag);
	}
	return rc;
}

// cmd 20: pure forward
ams::Result NsROAppControlDataService::GetAppControlData20(u8 source, u8 flag1, u8 flag2, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<Struct0xC> out_size) {
	const struct { u8 source; u8 flag1; u8 flag2; u64 tid; } in = {source, flag1, flag2, tid};
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData20, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("(%u, 0x%016lx, buf[0x%lx]) // %x", source, tid, buffer.GetSize(), rc);
	return rc;
}

// cmd 21: pure forward
ams::Result NsROAppControlDataService::GetAppControlData21(u8 source, u8 flag1, u8 flag2, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<Struct0xC> out_size) {
	const struct { u8 source; u8 flag1; u8 flag2; u64 tid; } in = {source, flag1, flag2, tid};
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData21, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("(%u, 0x%016lx, buf[0x%lx]) // %x", source, tid, buffer.GetSize(), rc);
	return rc;
}

// cmd 22: pure forward
ams::Result NsROAppControlDataService::GetAppControlData22(u8 source, u8 flag1, u8 flag2, u64 tid, const ams::sf::OutBuffer &buffer, ams::sf::Out<Struct0xC> out_size) {
	const struct { u8 source; u8 flag1; u8 flag2; u64 tid; } in = {source, flag1, flag2, tid};
	Result rc = serviceDispatchInOut(this->srv.get(), NsROAppControlDataInterfaceCmdId::GetAppControlData22, in, *out_size.GetPointer(),
		.buffer_attrs = {SfBufferAttr_HipcMapAlias | SfBufferAttr_Out},
		.buffers = {{buffer.GetPointer(), buffer.GetSize()}},
	);
	FILE_LOG_IPC_CLASS("(%u, 0x%016lx, buf[0x%lx]) // %x", source, tid, buffer.GetSize(), rc);
	return rc;
}
