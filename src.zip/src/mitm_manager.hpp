/*
 * Copyright (c) 2021 p-sam
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 */

#pragma once

#include "libams.hpp"
#include "ns_srvget_mitm_service.hpp"

enum {
	MitmManagerPort_NsAm2,
	MitmManagerPort_NsRo,
	MitmManagerPort_Count,
};

static constexpr size_t MitmManagerMaxSessions =
	1 + NsAm2MitmService::GetMaxSessions() + NsRoMitmService::GetMaxSessions();

// CanManageMitmServers MUST be true for MitM servers to work
struct MitmManagerOptions : public ams::sf::hipc::DefaultServerManagerOptions {
	static constexpr bool CanManageMitmServers = true;
};

class MitmManager : public ams::sf::hipc::ServerManager<MitmManagerPort_Count, MitmManagerOptions, MitmManagerMaxSessions> {
	private:
		virtual ams::Result OnNeedsToAccept(int port_index, Server* server) override;
	public:
		ams::Result RegisterServers();

		static constexpr bool HasAtLeastOneServiceDefined() {
			return MitmManagerPort_Count > 0;
		}
};
