/*
 * sys-icon - main.cpp
 * Uses the original __appInit/main() init pattern which works with this project's build setup.
 */

#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <malloc.h>

#include "libams.hpp"
#include "file_utils.hpp"
#include "mitm_manager.hpp"

extern "C" {
    extern u32 __start__;

    u32 __nx_applet_type = AppletType_None;
    u32 __nx_fs_num_sessions = 1;

    #define INNER_HEAP_SIZE 0x20000
    size_t nx_inner_heap_size = INNER_HEAP_SIZE;
    char   nx_inner_heap[INNER_HEAP_SIZE];

    void __libnx_initheap(void);
    void __appInit(void);
    void __appExit(void);

    alignas(16) u8 __nx_exception_stack[ams::os::MemoryPageSize];
    u64 __nx_exception_stack_size = sizeof(__nx_exception_stack);
    void __libnx_exception_handler(ThreadExceptionDump *ctx);
}

namespace ams {
    ncm::ProgramId CurrentProgramId = { 0x00FF69636F6EFF00ul };

    namespace result {
        bool CallFatalOnResultAssertion = true;
    }
}

void __libnx_exception_handler(ThreadExceptionDump *ctx) {
    ams::CrashHandler(ctx);
}

void __libnx_initheap(void) {
    void  *addr = nx_inner_heap;
    size_t size = nx_inner_heap_size;

    extern char *fake_heap_start;
    extern char *fake_heap_end;

    fake_heap_start = (char *)addr;
    fake_heap_end   = (char *)addr + size;
}

void __appInit(void) {
    ams::sm::Initialize();
    ams::hos::InitializeForStratosphere();
}

void __appExit(void) {
    ams::sm::Finalize();
}

int main(int argc, char **argv) {
    MitmManager serverManager;

    // InitializeAsync mounts SD via fsdevMountSdmc and starts logging
    R_ABORT_UNLESS(FileUtils::InitializeAsync());
    R_ABORT_UNLESS(serverManager.RegisterServers());

    FileUtils::LogLine("Entering server loop");

    ams::os::WaitableHolderType waitable{};
    while (true) {
        R_ABORT_UNLESS(serverManager.Process(&waitable));
    }

    return 0;
}
