#pragma once

#include <time.h>
#include <vector>
#include <string>
#include <atomic>
#include <cstdarg>

#include "libams.hpp"

#define FILE_LOG_FILE_PATH "sdmc:/" TARGET ".txt"

#define FILE_LOG_IPC(name, client_info, format, ...) \
    FileUtils::LogLine("%s::%s<%ld|0x%016lx>" format, name, __func__, client_info.process_id, client_info.program_id, ##__VA_ARGS__)

// Uses m_client_info to match the new service naming
#define FILE_LOG_IPC_CLASS(format, ...) \
    FILE_LOG_IPC(this->GetDisplayName(), this->m_client_info, format, ##__VA_ARGS__)

class FileUtils {
    public:
        static void Exit();
        static ams::Result Initialize();
        static bool IsInitialized();
        static bool WaitInitialized();
        static ams::Result InitializeAsync();
        static void LogLine(const char* format, ...);
};
