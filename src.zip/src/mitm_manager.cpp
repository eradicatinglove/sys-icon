/*
 * Copyright (c) 2021 p-sam
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 */

#include "mitm_manager.hpp"
#include "file_utils.hpp"

ams::Result MitmManager::OnNeedsToAccept(int port_index, Server* server) {
	std::shared_ptr<Service> fsrv;
	ams::sm::MitmProcessInfo client_info;
	server->AcknowledgeMitmSession(std::addressof(fsrv), std::addressof(client_info));

#define _MITM_ACCEPT(INTERFACE, SERVICE) \
	this->AcceptMitmImpl(server, ams::sf::CreateSharedObjectEmplaced<INTERFACE, SERVICE>(decltype(fsrv)(fsrv), client_info), fsrv)

	switch (port_index) {
		case MitmManagerPort_NsAm2:
			return _MITM_ACCEPT(NsServiceGetterMitmInterface, NsAm2MitmService);
		case MitmManagerPort_NsRo:
			return _MITM_ACCEPT(NsServiceGetterMitmInterface, NsRoMitmService);
		AMS_UNREACHABLE_DEFAULT_CASE();
	}

#undef _MITM_ACCEPT
}

ams::Result MitmManager::RegisterServers() {
	FileUtils::LogLine("Registering NsAm2MitmService (ns:am2)");
	R_TRY((this->RegisterMitmServer<NsAm2MitmService>(MitmManagerPort_NsAm2, NsAm2MitmService::GetServiceName())));

	FileUtils::LogLine("Registering NsRoMitmService (ns:ro)");
	R_TRY((this->RegisterMitmServer<NsRoMitmService>(MitmManagerPort_NsRo, NsRoMitmService::GetServiceName())));

	FileUtils::LogLine("RegisterServers complete");
	return ams::ResultSuccess();
}
